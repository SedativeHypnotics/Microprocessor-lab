nasm -f elf 05_sihan.asm && ld -m elf_i386 -s -o 05_sihan 05_sihan.o && ./05_sihan
